# Source and license of the files in this directory


## stent.nrrd

A 3D volume converted from stent.npz from the imageio project.
https://imageio.readthedocs.io/en/latest/standardimages.html

It is in the public domain.


## l.nrrd

Unknown
