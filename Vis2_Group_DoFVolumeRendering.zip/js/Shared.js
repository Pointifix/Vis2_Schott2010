export const MAX_SLICES_COUNT = 512;

window.focal_plane_distance = 100;
window.maxSlicesVolume = 0;
